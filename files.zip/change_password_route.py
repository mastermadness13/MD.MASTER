"""
change_password_route.py

Server-side implementation for the change-password panel.
This is where the real security lives — the template/JS are just UX.

Assumes:
  - Flask-Login for `current_user` / `@login_required`
  - Flask-WTF for CSRF (already handled globally if you use `CSRFProtect(app)`)
  - Flask-Limiter for rate limiting
  - SQLite via your existing db module (`db.execute` / `db.commit` — adjust
    to whatever wrapper ROPEY V5 already uses)
"""

import re
from datetime import datetime, timezone

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from flask_login import login_required, current_user, logout_user
from werkzeug.security import generate_password_hash, check_password_hash

# from your_app.extensions import limiter, db
# from your_app.common_passwords import is_common_password  # see note below

auth_bp = Blueprint("auth", __name__)

MIN_PASSWORD_LENGTH = 12


def validate_password_policy(new_password: str, current_password_hash: str) -> str | None:
    """
    Returns an Arabic error message if the password is invalid, else None.
    This is the single source of truth for the policy — the client-side
    checklist is only a preview of these same rules.
    """
    if len(new_password) < MIN_PASSWORD_LENGTH:
        return f"يجب ألا تقل كلمة المرور عن {MIN_PASSWORD_LENGTH} حرفاً"

    if not re.search(r"[a-zA-Z]", new_password):
        return "يجب أن تحتوي كلمة المرور على حرف واحد على الأقل"

    if not re.search(r"[0-9]", new_password):
        return "يجب أن تحتوي كلمة المرور على رقم واحد على الأقل"

    # Don't allow the new password to equal the old one. Compare via the
    # hash, never by storing/keeping the old plaintext around.
    if check_password_hash(current_password_hash, new_password):
        return "يجب أن تكون كلمة المرور الجديدة مختلفة عن كلمة المرور الحالية"

    # Optional but recommended: reject common/breached passwords.
    # Cheapest real option is the HaveIBeenPwned k-anonymity API (only the
    # first 5 chars of the SHA-1 hash leave your server, never the password
    # itself) or a bundled local top-N list for offline use.
    # if is_common_password(new_password):
    #     return "كلمة المرور هذه شائعة جداً وغير آمنة، الرجاء اختيار كلمة مرور أخرى"

    return None


@auth_bp.route("/account/security/change-password", methods=["GET", "POST"])
@login_required
# @limiter.limit("5 per 15 minutes")  # rate-limit change attempts per user/IP
def change_password():
    if request.method == "GET":
        return render_template("account/change_password.html", success=False, form_error=None)

    current_password = request.form.get("current_password", "")
    new_password = request.form.get("new_password", "")
    confirm_password = request.form.get("confirm_password", "")

    # 1. Re-verify the current password server-side. Never trust that the
    #    client already checked this.
    if not check_password_hash(current_user.password_hash, current_password):
        # Generic message — don't reveal whether the account exists or
        # which field was wrong beyond "current password", and never echo
        # any submitted password back in the response or logs.
        flash("كلمة المرور الحالية غير صحيحة")
        return render_template(
            "account/change_password.html",
            success=False,
            form_error="كلمة المرور الحالية غير صحيحة",
        )

    # 2. Confirm match (already checked client-side, but that's advisory).
    if new_password != confirm_password:
        return render_template(
            "account/change_password.html",
            success=False,
            form_error="كلمتا المرور الجديدتان غير متطابقتين",
        )

    # 3. Full policy check against the real rules.
    policy_error = validate_password_policy(new_password, current_user.password_hash)
    if policy_error:
        return render_template(
            "account/change_password.html",
            success=False,
            form_error=policy_error,
        )

    # 4. Hash and store. werkzeug's default (scrypt in modern Werkzeug) is
    #    fine; swap to argon2-cffi's PasswordHasher if you specifically
    #    want Argon2id.
    new_hash = generate_password_hash(new_password)

    # db.execute(
    #     """
    #     UPDATE users
    #     SET password_hash = ?, password_changed_at = ?, session_version = session_version + 1
    #     WHERE id = ?
    #     """,
    #     (new_hash, datetime.now(timezone.utc).isoformat(), current_user.id),
    # )
    # db.commit()

    # 5. Invalidate existing sessions (this device included, forcing a
    #    clean re-login) by bumping session_version above and checking it
    #    in a before_request hook — see notes below. At minimum, clear the
    #    current session here.
    logout_user()
    session.clear()

    flash("تم تغيير كلمة المرور بنجاح، الرجاء تسجيل الدخول مجدداً")
    return redirect(url_for("auth.login"))


# --- before_request hook (register on the app or a blueprint) ---------------
#
# @app.before_request
# def enforce_session_version():
#     if current_user.is_authenticated:
#         if session.get("session_version") != current_user.session_version:
#             logout_user()
#             session.clear()
#             flash("انتهت صلاحية الجلسة، الرجاء تسجيل الدخول مجدداً")
#             return redirect(url_for("auth.login"))
#
# This is what makes "password change logs out other devices" actually
# true, rather than just a line in the success message. Store
# `session_version` in the session at login time, compare it against the
# DB value on every request.
