/**
 * auth_passwords.js
 *
 * Client-side behavior for the change-password panel.
 * IMPORTANT: everything here is UX sugar. The server re-validates all of it.
 * Never trust this file to be the actual security boundary.
 */

(function () {
  'use strict';

  const COMMON_PASSWORDS = new Set([
    // A tiny client-side sanity check only — NOT a substitute for the
    // server checking against a real breached-password list (e.g. HIBP
    // k-anonymity API, or a local top-10k list). This just catches the
    // most obvious mistakes before a round trip.
    'password', 'password123', '12345678', '123456789', 'qwerty123',
    'letmein', 'welcome123', 'admin123', 'zawara123', 'ropey12345'
  ]);

  function togglePassword(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (!input) return;

    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';

    const icon = btn.querySelector('.material-symbols-outlined');
    if (icon) icon.textContent = isHidden ? 'visibility_off' : 'visibility';

    btn.setAttribute('aria-label', isHidden ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
  }
  // Exposed globally because the template calls it via inline onclick.
  window.togglePassword = togglePassword;

  function setRequirementState(id, met) {
    const el = document.getElementById(id);
    if (!el) return;
    el.dataset.met = met ? 'true' : 'false';
    el.classList.toggle('requirement-met', met);

    const icon = el.querySelector('.material-symbols-outlined');
    if (icon) icon.textContent = met ? 'check_circle' : 'radio_button_unchecked';
  }

  function evaluateStrength(pwd) {
    // Simple heuristic for the meter only — not a real entropy calculation,
    // and not used to block submission by itself.
    let score = 0;
    if (pwd.length >= 12) score++;
    if (pwd.length >= 16) score++;
    if (/[a-zA-Z]/.test(pwd) && /[0-9]/.test(pwd)) score++;
    if (/[^a-zA-Z0-9]/.test(pwd)) score++;
    if (COMMON_PASSWORDS.has(pwd.toLowerCase())) score = 0;
    return Math.min(score, 4);
  }

  function renderStrength(score) {
    const labels = ['ضعيفة جداً', 'ضعيفة', 'متوسطة', 'جيدة', 'قوية'];
    const label = document.getElementById('strength-label');
    if (label) label.textContent = labels[score];

    for (let i = 1; i <= 4; i++) {
      const seg = document.getElementById('seg-' + i);
      if (!seg) continue;
      seg.classList.remove('bg-surface-container-highest', 'bg-error', 'bg-warning', 'bg-success-green');
      if (i > score) {
        seg.classList.add('bg-surface-container-highest');
      } else if (score <= 1) {
        seg.classList.add('bg-error');
      } else if (score <= 2) {
        seg.classList.add('bg-warning');
      } else {
        seg.classList.add('bg-success-green');
      }
    }
  }

  function initChangePasswordForm() {
    const form = document.querySelector('form[data-validate-form]');
    if (!form) return;

    const currentInput = document.getElementById('current_password');
    const newInput = document.getElementById('new_password');
    const confirmInput = document.getElementById('confirm_password');
    const confirmError = document.getElementById('confirm-password-error');
    const submitBtn = form.querySelector('.auth-submit-btn');

    function validateNewPassword() {
      const pwd = newInput.value;
      const current = currentInput ? currentInput.value : '';

      setRequirementState('req-length', pwd.length >= 12);
      setRequirementState('req-letter', /[a-zA-Z]/.test(pwd));
      setRequirementState('req-digit', /[0-9]/.test(pwd));
      // Client can only compare against what current_password currently holds
      // in the DOM — the server does the real "not identical" check against
      // the stored hash.
      setRequirementState('req-different', pwd.length > 0 && pwd !== current);

      renderStrength(evaluateStrength(pwd));
      validateConfirmMatch();
    }

    function validateConfirmMatch() {
      if (!confirmInput.value) {
        confirmError.classList.add('hidden');
        confirmInput.setCustomValidity('');
        return true;
      }
      const matches = confirmInput.value === newInput.value;
      confirmError.classList.toggle('hidden', matches);
      confirmInput.setCustomValidity(matches ? '' : 'كلمتا المرور غير متطابقتين');
      return matches;
    }

    newInput.addEventListener('input', validateNewPassword);
    confirmInput.addEventListener('input', validateConfirmMatch);

    form.addEventListener('submit', function (e) {
      // Client-side gate is a UX convenience only. Disabling the button
      // during submit prevents accidental double-submits (e.g. double-click
      // triggering two password-change requests / hitting a rate limit
      // unnecessarily) — it does not replace server validation.
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'جارٍ التحديث...';
      }
    });
  }

  document.addEventListener('DOMContentLoaded', initChangePasswordForm);
})();
